% Author: Jorge. A Navas, The University of Melbourne 2013

:- module(counter_instrument, [counter_instrument/2, counter_instrument/5]).

%  Own libraries
:- use_module(readprog).
:- use_module(writeprog).
:- use_module('../adt/balanced_tree').
:- use_module('../analysis/scc').
%  Ciao libraries
:- use_module(library(read)).
:- use_module(library(write)).
:- use_module(library(filenames), [file_name_extension/3]).
:- use_module(library(lists),     [last/2]).
:- use_module(library(assoc)).

% To understand clpr operators
:- op(700, xfx, [(.=.),(.<>.),(.<.),(.=<.),(.>.),(.>=.)]).

% TODO/FIXME: for simplicity, this transformation add new variables
% which are not added into the dictionary in the clause/2
% predicate. Thus, make sure that the dictionary is never used.
	                  
%------------------------------------------------------------------------------%
% counter_instrument(+,+,+,+,-)
% counter_instrument(+,+,+,+,+,+,+,-)
%------------------------------------------------------------------------------%
% For each recursive clause of the form p(X):- ..., q(X) it will transform
% it into: p(X,K):- K>=0, ..., K1=K-1, p(X,K1).
%------------------------------------------------------------------------------%
:- push_prolog_flag(multi_arity_warnings,off).
counter_instrument(InFile,OutFile):-
        readprog(InFile, Prog, Dirs), 	
        sortClauses(Prog,Ps,Procs),
        counter_instrument(Ps, Procs, Dirs, InFile,  OutFile).
counter_instrument(Ps, Procs, Dirs, InFile, OutFile):-
        /* here transformations */
        recursive_preds(Ps, Procs, RecPreds, _),
        % add_last_arg_in_rec_atom/6 invalidates Procs, Dirs,
        % RecPreds, and NewPs. Thus, they must be recomputed.
        add_last_arg_in_rec_atom(Procs,Dirs,RecPreds,NewPs,NewProcs,NewDirs),
        % TODO/FIXME: for simplicity SCCs are computed twice!
        recursive_preds(NewPs, NewProcs, NewRecPreds, SCCs),
        recursive_clauses(NewPs, NewProcs, RecCls),	
        empty_assoc(EmptyClsMap),
        compute_stable_map_pred_to_clauses(NewProcs, EmptyClsMap, ClsMap),
        instrument_rec_preds(NewPs,root,_,ClsMap,SCCs,NewRecPreds,RecCls,InstrCls),
        /* here write the transformed program into OutFile */		 
        file_name_extension(InFile,Base,Extension),	
        atom_concat(Base,'__counter_instr', Base0),
        atom_concat(Base0,Extension, OutFile),
        open(OutFile,write,Stream),	
        writeprog(InstrCls,  NewDirs, Stream),
        close(Stream).
:- pop_prolog_flag(multi_arity_warnings).	

% This predicate takes the whole SCC and tranform it.
instrument_rec_preds([],MarkList,MarkList,_,_,_,_,[]).
instrument_rec_preds([P|Ps], MarkListIn, MarkListOut, ClsMap, SCCs, RecPreds, 
                     RecCls, NewCls):-                     
        % already transformed
        search_tree(MarkListIn, P, black), % P already visited
        instrument_rec_preds(Ps, MarkListIn, MarkListOut, ClsMap, SCCs, 
                             RecPreds, RecCls, NewCls).
instrument_rec_preds([P|Ps],MarkListIn,MarkListOut,ClsMap,SCCs,RecPreds, 
                     RecCls, NewCls):-
        % recursive predicate
        member(P,RecPreds),
        !,
        find_scc_pred(SCCs,P,SCC),
        instrument_scc(SCC,MarkListIn,MarkListMid,ClsMap,RecPreds,RecCls,SCC_Cls),
        instrument_rec_preds(Ps, MarkListMid, MarkListOut, ClsMap, SCCs, 
                             RecPreds, RecCls, RestCls),
        append(SCC_Cls, RestCls, NewCls).
instrument_rec_preds([P|Ps], MarkListIn, MarkListOut, ClsMap, SCCs, RecPreds, 
                     RecCls, NewCls):-
        % non-recursive predicate
        get_assoc(P, ClsMap, P_Cls),
        !,
        instrument_rec_preds(Ps, MarkListIn, MarkListOut, ClsMap, SCCs, 
                             RecPreds, RecCls, RestCls),
        append(P_Cls, RestCls, NewCls).
instrument_rec_preds([_|Ps], MarkListIn, MarkListOut, ClsMap, SCCs, RecPreds, 
                     RecCls, NewCls):-
        % builtin
        instrument_rec_preds(Ps, MarkListIn, MarkListOut, ClsMap, SCCs, 
                             RecPreds, RecCls, NewCls).
                    
find_scc_pred([(non_recursive,_)|SCCs],F/A, SCC):- find_scc_pred(SCCs,F/A,SCC).
find_scc_pred([(recursive,SCC)| _],F/A, SCC)    :- member(F/A,SCC),!.
find_scc_pred([(recursive,_)|SCCs],F/A, SCC)    :- find_scc_pred(SCCs,F/A,SCC).
                
instrument_scc(SCCs,MarkListIn,MarkListOut,ClsMap,RecPreds,RecCls,NewCls):-
        SCCs = [EntrySCC|_Tail],
        get_assoc(EntrySCC, ClsMap, EntrySCC_Cls),
        add_cond_entry_scc(EntrySCC_Cls,EntrySCC,1,RecPreds,RecCls,EntrySCC_NewCls),
        update_assoc(EntrySCC, ClsMap, EntrySCC_NewCls, NewClsMap, _OldVal),
        % mark node as visited
        insert_tree(MarkListIn,EntrySCC,black,MarkListMid), 
        instrument_rest_scc(SCCs,EntrySCC,SCCs,MarkListMid,MarkListOut, 
                            NewClsMap,NewCls).

instrument_rest_scc([], _, _, MarkList, MarkList, _, []).
instrument_rest_scc([P|Ps],EntrySCC,SCCs,MarkListIn,MarkListOut,ClsMap,NewCls):-
        get_assoc(P, ClsMap, P_Cls),
        add_counter_decr(P_Cls, EntrySCC, SCCs, New_P_Cls),
        insert_tree(MarkListIn,P,black,MarkListMid), % mark node as visited
        instrument_rest_scc(Ps, EntrySCC, SCCs, MarkListMid, MarkListOut, 
                            ClsMap, RestCls),
        append(New_P_Cls, RestCls, NewCls).

add_counter_decr([], _, _, []).
add_counter_decr([clause((H:-B),Vs) | Cls], F/A, SCCs, 
                 [clause((H:-NewB),Vs) | NewCls]) :-
        add_counter_decr_body(B, F/A, H, SCCs, NewB),
        add_counter_decr(Cls, F/A, SCCs, NewCls).

% add_counter_decr_body(+Body,+F/A,+Term,SCCs,-NewBody).
add_counter_decr_body(true,_EntrySCC,_,_,true).
add_counter_decr_body((B,Bs),EntrySCC,ClHead,SCCs,(NewB,NewBs)):-
        add_counter_decr_lit(B,EntrySCC,ClHead,SCCs,NewB),
        add_counter_decr_body(Bs,EntrySCC,ClHead,SCCs,NewBs).
add_counter_decr_body(B,EntrySCC,ClHead,SCCs,NewB):-
        add_counter_decr_lit(B,EntrySCC,ClHead,SCCs,NewB).


% F/A is EntrySCC
add_counter_decr_lit(B,F/A,ClHead,SCCs,NewB):-
        functor(B,BF,BA),
        ( (BF==F, BA==A) ->
          % unify K with last argument of the clause head and K1 with
          % the last argument of the body literal.
	arg_counter_param(ClHead, K),
	% needed if some unification has been already done
	free_last_argument(B, NB),
	arg_counter_param(NB, K1),
	% TODO/FIXME: add K1 into dictionary of clause/2.
          NewB = (clp_meta([ K1 .=. K - 1]), NB)
        ;
          ( member(BF/BA,SCCs) ->
	  % unify K with last argument of the clause head
	  arg_counter_param(ClHead, K),
	  arg_counter_param(B, K)
          ;
            true  
          ),
	NewB = B
        ).

% free_last_argument(+term,-term)
free_last_argument(Term, NewTerm):-
        Term =.. L,
        free_last_argument_aux(L, NL),
        NewTerm =.. NL.
free_last_argument_aux([],[]).
free_last_argument_aux([_],[_Fresh]).
free_last_argument_aux([H|T],[H|NT]):-
        free_last_argument_aux(T, NT).

% This predicate assumes that the counter parameter introduced by
% instrumentation is always the last one.
arg_counter_param(Term, K):- functor(Term,_F,A), arg(A,Term,K).
        
% add_cond_entry_scc(+Cls,F/A,ClId,+RecPreds,+RecCls,-NewCls).
% IMPORTANT: add the constraint only if the clause is recursive.
% Pre: H = F/A
add_cond_entry_scc([], _, _, _, _, []).
add_cond_entry_scc([clause((H:-B),Vs) | Cls], F/A, ClId, RecPreds, RecCls, 
                   [clause((H:-NewB),Vs) | NewCls]) :-
        member(F/A/ClId, RecCls),
        !,
        % unify K with the last argument of the clause head.
        arg_counter_param(H,K),
        NewB = (clp_meta([ K .>=. 0]), B),
        % unify K with the last argument of each recursive body literal.
        unify_arg_with_rec_body_lits(B,K,RecPreds),
        NextClId is ClId + 1,
        add_cond_entry_scc(Cls, F/A, NextClId,  RecPreds, RecCls, NewCls).
add_cond_entry_scc([Cl | Cls], F/A, ClId,  RecPreds, RecCls, [ Cl | NewCls]):-
        NextClId is ClId + 1,
        add_cond_entry_scc(Cls, F/A, NextClId, RecPreds, RecCls, NewCls).
        
% unify_arg_with_rec_body_lits(?Body, -var,-list).
% traverse a body and unify the last argument of any recursive literal
% with Arg.
unify_arg_with_rec_body_lits(true, _, _).
unify_arg_with_rec_body_lits((B,Bs), Arg, RecPreds):-
        functor(B,F,A),
        ( member(F/A,RecPreds) -> arg_counter_param(B,Arg) ; true),
        unify_arg_with_rec_body_lits(Bs, Arg, RecPreds).
unify_arg_with_rec_body_lits(B, Arg, RecPreds):-
        functor(B,F,A),
        ( member(F/A,RecPreds) -> arg_counter_param(B,Arg) ; true).
        

%-------------------------------------------------------------------------------%
% add_last_arg_in_rec_atom(+Procs,+Dirs,+RecPreds,-NewPs,-NewProcs,-NewDirs).
%-------------------------------------------------------------------------------%
% for each atom that appears in the head or body literal it adds a new
% argument in the last position.
%-------------------------------------------------------------------------------%
add_last_arg_in_rec_atom(Procs, Dirs, RecPreds, NewPs, NewProcs, NewDirs):-
        add_last_arg_in_rec_atom_(Procs,RecPreds,NewProcs),
        unzip_proc_list(NewProcs, NewPs),
        update_directives(Dirs, RecPreds, NewDirs).

% IMPORTANT: this predicate must be updated if more directives are
% added in tclp_package.pl
update_directives([],_,[]).
update_directives([Dir|Dirs],RecPreds,[NewDir|NewDirs]):-
        update_directive(Dir, RecPreds, NewDir),
        update_directives(Dirs,RecPreds,NewDirs).

update_directive(tabled(Pred)       , RecPs, tabled(NewPred)):-
        add_last_arg_in_atom(Pred, RecPs, NewPred, Last, ChangedFlag),
        ( ChangedFlag==1 ->
          Last = num
        ; 
          true
        ).
update_directive(no_cache(Pred)     , RecPs, no_cache(NewPred)):-
        add_last_arg_in_atom(Pred, RecPs, NewPred, _, _).
update_directive(discriminants(Pred), RecPs, discriminants(NewPred)):-
        add_last_arg_in_atom(Pred, RecPs, NewPred, Last, ChangedFlag),
        ( ChangedFlag==1 ->
          Last = d
        ; 
          true
        ).
update_directive(mode(Pred)         , RecPs, mode(NewPred)):-
        add_last_arg_in_atom(Pred, RecPs, NewPred, Last, ChangedFlag),
        ( ChangedFlag==1 ->
          Last = in
        ; 
          true
        ).
update_directive(Dir, _, Dir).

unzip_proc_list([],[]).
unzip_proc_list([proc(P,_Cls)|Procs],[P|RestPs]):-  
        unzip_proc_list(Procs,RestPs).

add_last_arg_in_rec_atom_([], _, []).
add_last_arg_in_rec_atom_([proc(F/A,Cls)|Procs], RecPreds, [proc(NewP,NewCls)| NewProcs]):-
        add_last_arg_in_rec_atom_clause(Cls, RecPreds, NewCls),
        ( member(F/A,RecPreds)->
	A1 is A + 1,
	NewP = F/A1
        ;
	NewP = F/A
        ),
        add_last_arg_in_rec_atom_(Procs, RecPreds, NewProcs).
        
                         
add_last_arg_in_rec_atom_clause([],_,[]).
add_last_arg_in_rec_atom_clause([clause((H:-B),Vs) | Cls], RecPreds, 
                                [clause((NewH:-NewB),Vs) | NewCls]):-
        add_last_arg_in_atom(H, RecPreds, NewH, _Last, _ChangedFlag),
        % TODO/FIXME: add Last into dictionary of clause/2 if ChangedFlag=1
        add_last_arg_in_body(B, RecPreds, NewB),
        add_last_arg_in_rec_atom_clause(Cls, RecPreds, NewCls).
        
% Last is a free variable corresponding to the last argument of Goal
% if ChangedFlag=1.
add_last_arg_in_atom(Goal, RecPreds, NewGoal, Last, ChangedFlag):-
        functor(Goal,F,A),
        ( member(F/A, RecPreds) ->
          Goal =.. L,
          append(L,[Last], L1),
          NewGoal =.. L1,
	ChangedFlag=1
        ;
          NewGoal = Goal,
	ChangedFlag=0
        ).

add_last_arg_in_body(true, _, true).
add_last_arg_in_body((B,Bs), RecPreds, (NewB,NewBs)):-
        add_last_arg_in_atom(B, RecPreds, NewB, _Last, _ChangedFlag),
        add_last_arg_in_body(Bs, RecPreds, NewBs).
add_last_arg_in_body(B, RecPreds, NewB):-
        add_last_arg_in_atom(B, RecPreds, NewB, _Last, _ChangedFlag).
        

%-------------------------------------------------------------------------------%
% compute_map_pred_to_clauses(+Procs,+Assoc0,-Assoc1)                   
%-------------------------------------------------------------------------------%
% For each predicate F/A it finds its clauses and store them into an
% associative list.  Clauses are stored in the same order than appear
% in Procs.
%-------------------------------------------------------------------------------%
compute_stable_map_pred_to_clauses([],Assoc,Assoc).
compute_stable_map_pred_to_clauses([proc(F/A, Cls) | Procs], Assoc0, Assoc2):-
        compute_stable_map_pred_to_clauses_aux(Cls, F/A, Assoc0, Assoc1),
        compute_stable_map_pred_to_clauses(Procs, Assoc1, Assoc2).
                
compute_stable_map_pred_to_clauses_aux([], _, Assoc, Assoc).
compute_stable_map_pred_to_clauses_aux([clause((H:-B),Vs) | Cls], F/A, 
                                       Assoc, Assoc2):-
        functor(H, F, A),
        !,
        ( get_assoc(F/A, Assoc, PsCls) ->
	append(PsCls, [clause((H:-B),Vs)], NewPsCls)
        ;
          NewPsCls = [clause((H:-B),Vs)]
        ),
        put_assoc(F/A,Assoc,NewPsCls,Assoc1),
        compute_stable_map_pred_to_clauses_aux(Cls, F/A, Assoc1, Assoc2).
	        
        
        

                   

