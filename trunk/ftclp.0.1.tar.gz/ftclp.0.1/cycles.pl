% Jorge. A Navas, The University of Melbourne 2013

%===============================================================================%
%                           TO HANDLE CYCLES
%===============================================================================%

% WARNING: THIS FILE IS TO BE INCLUDED BY tclp.pl
%          DO NOT TRY TO LOAD IT DIRECTLY.

% Here we call a fake infeasible path if the path was infeasible due
% to some counter introduced by the the counter instrumentation used
% to force termination.

 
	
%------------------------------------------------------------------------------%%
% mark_fake_false(+Stack,+list,+list,+Solver)
%-------------------------------------------------------------------------------%
% Decides which infeasible paths were spurious due to fake constraints
% used to force termination and which not. This is vital for
% correctness. The information has to be asserted because it has to be
% kept during backtracking. 
%
% mark_fake_false/4 is called after an infeasible path has been
% detected. We traverse the Stack to find the closest clause C to the
% infeasibility point. Then, we check if the C corresponds to a
% recursive predicate. If not, we fail (meaning it's a real infeasible
% path). Otherwise, we know for sure (by construction) that C has a
% fake variable K used to force termination. Then, we replace in the
% interpolant I_C K with 0 (i.e., I_C[0/k]). If the result is false
% then we mark as "fake" the infeasible path.
% -------------------------------------------------------------------------------%
:- data '$fake_false'/1.
mark_fake_false(Stack, RecPreds, RecCls, Solver):-
	% To avoid side-effects from unification between Goal and the
	% memo table.
	\+(\+(mark_fake_false_aux(Stack, RecPreds, RecCls, Solver))).
mark_fake_false_aux(Stack, RecPreds, _RecCls, Solver):-
	is_enabled_option(cycle_subsumption),
	goal_stack__previous_clause(Stack, Cl, _RestStack), 
 	Cl = clause(Goal,K,Depth,_,_,_), functor(Goal,F,A),
	member(F/A, RecPreds),
	%member(F/A/K,RecCls),
	get_map_node_to_unique_id(Goal,K,Depth,MemoId),
	lookup_intp_tables(Goal,_, MemoId, Intp, _, _), 
	!,
	% Pre: last argument is the counter to force termination.
	%      This is ensured by a program transformation.
	get_var_attribute(Goal, A, FakeK),	
	rename_and_check_unsat(Intp, [FakeK], [0], Solver),
	format("Unrolling stopped with clause ~q of ~q at depth ~q.\n",
                 [K, F/A, Depth]), 
	retract_fact('$fake_false'(OldSet)),
	insert_set(OldSet, F/A/K/Depth, NewSet),
	asserta_fact('$fake_false'(NewSet)).

rename_and_check_unsat(F, OldVs, NewVs, Solver):-
	solver_rename_formula(Solver,  F , OldVs, NewVs, NewF),
	solver_sibling_push(Solver),
	solver_sibling_assert_formula(Solver, NewF),
	solver_sibling_incremental(Solver, [], SatFlag),
	!,
	solver_sibling_reset(Solver),
	SatFlag == ff.

get_fake_false_ids(Ids):-
	is_enabled_option(cycle_subsumption),
	!,
	current_fact('$fake_false'(Set)),
	set_to_list(Set,List),
	map_ids(List,Ids).
get_fake_false_ids([]):-!.

map_ids([],[]).
map_ids([F/A/K/Depth|Xs], [Y|Ys]):-
	functor(Goal,F,A),
	get_map_node_to_unique_id(Goal,K,Depth,Y),	
	map_ids(Xs,Ys).

% get_depth_from_lower_fake(+,+,-,-)
get_depth_from_lower_fake(F/A, Depth, K , LowerDepth):-
	current_fact('$fake_false'(Set)),
	!,
	lookup_set(Set,F/A/K/LowerDepth), 
	LowerDepth > Depth.

print_fake_nodes([],_Msg).
print_fake_nodes([F/A/K/Depth | Rs], Msg):-
        format("~w clause ~q of ~q at depth ~q.\n",[Msg, K,F/A,Depth]),
        print_fake_nodes(Rs, Msg).

%------------------------------------------------------------------------------%
% promote_fake_infeasible_to_actual(+,+,+,+).
% Try to find a node that has an ancestor Ancestor which subsumes it.
%------------------------------------------------------------------------------%
promote_fake_infeasible_to_actual(AncestorGoal, Depth, Solver, OutStream):-
	is_enabled_option(cycle_subsumption),
	debug_message("----------------------------------------------\n",[]),
	functor(AncestorGoal, F, A),
	get_depth_from_lower_fake(F/A,  Depth, ClId, LowerDepth),
	get_map_node_to_unique_id(AncestorGoal,ClId,LowerDepth,ChildNodeId),
	% These two calls should not fail
	lookup_intp_tables(_,_, ChildNodeId, _, ChildNode, ChildPrefix),
	lookup_intp_pred_table(AncestorGoal,AncestorIntp,AncestorNode,AncestorPrefix),
	% prefix_between/3 may fail 
          prefix_between(AncestorPrefix, ChildPrefix, PrefixToExec),
	( check_invariant_incr(AncestorGoal, PrefixToExec, AncestorIntp, Solver) ->
	  format("FAILED to subsume clause ~q of ~q at depth ~q.\n",
	         [ClId, F/A, LowerDepth])
	;
	  % TODO/FIXME: remove from the clause memo table the entry
	  % corresponding to F/A/ClId/LowerDepth
	  format("PROVED that clause ~q of ~q at depth ~q is subsumed.\n",
	         [ClId, F/A, LowerDepth]),
	  retract_fact('$fake_false'(OldSet)),
	  remove_set(OldSet, F/A/ClId/LowerDepth, NewSet),	  
	  asserta_fact('$fake_false'(NewSet)),
	  % DOT output
	  mark_subsumed_trans(ChildNode, AncestorNode, OutStream)
          ),
	debug_message("-----------------------------------------------\n",[]),
	!.	
promote_fake_infeasible_to_actual(_,_,_,_):- !.

rename_and_negate(OldFormula, OldGoal, Solver, NewGoal, NotNewFormula):-
	varset_attributes(OldGoal ,OldVs),
	varset_attributes(NewGoal ,NewVs),
	solver_rename_formula(Solver, OldFormula , OldVs, NewVs, NewFormula0),
	solver_mk_not(Solver, NewFormula0, NotNewFormula0),
	% Pre: last argument is the counter to force termination.
	% This is ensured by a program transformation.
	functor(NewGoal,_,N),
	get_var_attribute(NewGoal, N, K), 
	solver_rename_formula(Solver,  NotNewFormula0 , [K], [0], NotNewFormula).

 

list_head_tail([X]   , X,  []) :- !.
list_head_tail([X|Xs], X,  Xs) :- !.
list_head_tail(Xs    ,E, Ys) :- 
	format("ERROR ftclp: list_head_tail(~q,~q,~q)\n",[Xs,E,Ys]),
	halt.

%-------------------------------------------------------------------------------%
% Check if a candidate is invariant incrementally. Note that it may
% cover a large tree. We don't use interpolation so it could be
% expensive. Not sure whether the use of interpolation may make the
% process of getting invariants harder. We could assert a disjunctive
% formula into the solver as an option.
%-------------------------------------------------------------------------------%
% Important: the candidate AncestorIntp is invariant if
% check_invariant_incr/4 fails.
%-------------------------------------------------------------------------------%
check_invariant_incr(AncestorGoal, PrefixToExec, AncestorIntp, Solver):-
          solver_sibling_reset(Solver),
	abstract_str_path(PrefixToExec, NonDetPrefixToExec),
	% The execution of NonDetPath will produce a tree because some
	% clauses are undetermined.
	convert_str_path_to_term_list(NonDetPrefixToExec, NonDetPath),
	% Pre: last argument is the counter to force termination.
	% This is ensured by a program transformation.
	functor(AncestorGoal,_,N),
	get_var_attribute(AncestorGoal, N, K), 
	solver_sibling_push(Solver),
	solver_rename_formula(Solver,  AncestorIntp , [K], [0], AncestorIntp0),
 
	( solver_is_true(Solver, AncestorIntp0) ->
	    % success means it is not invariant   
	    debug_message("Cannot be invariant: candidate depends just on counter.\n",[]),
	    solver_sibling_pop(Solver)
	;
	  ( solver_is_false(Solver, AncestorIntp0) ->
              % success means it is not invariant   
	    debug_message("Cannot be invariant: candidate is false.\n",[]),
	    solver_sibling_pop(Solver)
            ;                
	    solver_sibling_assert_formula(Solver, AncestorIntp0),	  
 
  	    execute_path_aux([AncestorGoal], NonDetPath,_,Solver, 
	                      AncestorGoal, DescendantGoal),
	    rename_and_negate(AncestorIntp,AncestorGoal, Solver, 
	                      DescendantGoal,NotDescendantIntp),
	    solver_sibling_push(Solver),
	    solver_sibling_assert_formula(Solver, NotDescendantIntp),
	    solver_sibling_incremental(Solver,[],SatFlag),
	    ( is_enabled_option(debug) ->
	      atom_codes(AtomPath, NonDetPrefixToExec),
	      format("CYCLE TO CHECK: ~q\n",[AtomPath]),
	      solver_sibling_print(Solver),
	      ( SatFlag == ff -> 
                  format("***Path is INVARIANT!\n",[]) 
                ; 
                  format("***Path is NOT invariant.\n",[])
                )
	    ;
	      true
	    ),
	    ( SatFlag == ff ->
	      % the candidate holds for one derivation path.
	      % We force backtracking to try **all** paths.
	      solver_sibling_pop(Solver),
	      fail
	    ;
	      solver_sibling_reset(Solver)
	    )
            )
          ),
	!.

% execute_path(+,+,+,+,+,-)	
execute_path(Goals, Prefix, Suffix, Solver, InitG, LastG) :-
	execute_path_aux(Goals, Prefix, Suffix0, Solver, InitG, LastG0),
	( Suffix0 == [] ->
	  Suffix=Suffix0, LastG=LastG0
	;
	 list_head_tail(Suffix0,NextGoal,_),
	 execute_path([NextGoal],Suffix0,Suffix,Solver,LastG0,LastG)
          ).
execute_path_aux([], Suffix, Suffix,  _, LastG, LastG):- !.
execute_path_aux([constraints(Cs,_)| Goals], Suffix, EndSuffix, Solver,
                 LastG0,LastG1):-
	execute_constraints(Cs, Solver),
	execute_path_aux(Goals, Suffix, EndSuffix, Solver, LastG0, LastG1).
execute_path_aux([constraints(_Cs,_)| _Goals], _Suffix, _EndSuffix, Solver,_,_):-
	solver_sibling_pop(Solver),
	fail.
execute_path_aux([builtin(Builtin,_,Module)| Goals], Suffix, EndSuffix, Solver, 
                 LastG0,LastG1):- 
	wrapper_run_builtin(Module, Builtin),
	execute_path_aux(Goals, Suffix, EndSuffix, Solver, LastG0,LastG1).
execute_path_aux(Goals, [Goal/_], [], _Solver,_,Goal):-
	list_head_tail(Goals,GoalX,_),
	Goal = GoalX.
	%!.
execute_path_aux(Goals, [Goal/K | RestSuffix], EndSuffix, Solver,
                 _LastG0,LastG2):-
	list_head_tail(Goals,GoalX,RestGoals),
	Goal = GoalX,
	% K may be free or ground
          rule(Goal, K, Body),
	execute_clause(Goal, Body, RenamedBody, Solver),
	execute_body(RenamedBody, RestSuffix, NextSuffix, Solver, Goal, 
                       LastG1),  			      
	execute_path_aux(RestGoals, NextSuffix, EndSuffix, Solver, 
	                 LastG1, LastG2).
 
execute_constraints(Cs, Solver):-
          convert_clp_constraints_to_solver(Cs, SolverFormatCs, _),
	solver_sibling_push(Solver),
	solver_sibling_incremental(Solver, SolverFormatCs, SatFlag),
	SatFlag == tt.
	
execute_body(Body, Prefix, Suffix, Solver, LastG0, LastG1):-
	execute_path_aux(Body, Prefix, Suffix, Solver, LastG0, LastG1).

execute_clause(Goal, BodyCl, BodyClX, Solver):-
 
          extract_equalities_from_last_unification(Goal,[],_,_),
	rename_clause(Goal-BodyCl, Solver, _, GoalX-BodyClX),
	extract_equalities_from_last_unification(GoalX,[],_,HeadGoalCs),
	execute_clause_aux(HeadGoalCs, Solver).
execute_clause_aux([], Solver):-
	solver_sibling_push(Solver).
execute_clause_aux(HeadGoalCs, Solver):-
          HeadGoalCs = [_|_],
	solver_sibling_push(Solver),
	solver_sibling_incremental(Solver, HeadGoalCs, SatFlag),
	SatFlag == tt.
execute_clause_aux(_, Solver):-
	solver_sibling_pop(Solver),
	fail.

% prefix_between(+,+,-)
prefix_between(AncestorPrefix, ChildPrefix, PrefixToExec):-
          mk_dash(X), 
 	append(AncestorPrefix,[X|PrefixToExec],ChildPrefix).

%--------------------------------------------------------------------------%
% To control the unrolling of each recursive clause.
%--------------------------------------------------------------------------%
:- data '$unroll_depth'/2.
cleanup_unroll_depth_counters:-
	retractall_fact('$unroll_depth'(_,_)).

% init_unroll_depth(+RecPredLs, +InitVal)
% RecPredLs is a list of F/A terms and InitVal is a number.
init_unroll_depth([],_).
init_unroll_depth([F/A|Ps], InitVal):-
	asserta_fact('$unroll_depth'(F/A, InitVal)),
	init_unroll_depth(Ps, InitVal).

incr_unroll_depth([], _).
incr_unroll_depth([F/A/_Cl/_Depth| Xs], Incr):-
	retract_fact('$unroll_depth'(F/A, OldVal)),
	NewVal is OldVal + Incr,
	asserta_fact('$unroll_depth'(F/A, NewVal)),
	format("Increasing unrolling depth of ~q to ~q\n",[F/A, NewVal]),
	incr_unroll_depth(Xs, Incr).

%-------------------------------------------------------------------------%
% gen_forced_termination_constraint(+,+,+,-)
% Fail if no constraint is generated.
%-------------------------------------------------------------------------%
gen_forced_termination_constraint(Goal, RecPreds, Stack, C):-
	is_enabled_option(cycle_subsumption),
	functor(Goal, F, A),
	% goal must be recursive and first occurrence in the path
	(member(F/A, RecPreds), \+(goal_stack__is_cyclic(Stack, Goal, _))),
	% Pre: last argument is the counter to force termination.
	% This is ensured by a program transformation.
	get_var_attribute(Goal, A, K), 
	current_fact('$unroll_depth'(F/A, Val)),
	C = '.=.'(K, Val).

	
			
