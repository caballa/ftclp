:- op(750 , fx , (tabled)).
:- op(750 , fx , (no_cache)).
:- op(750 , fx , (discriminants)).
%% Deprecated
:- op(750 , fx , (mode)).

% To understand primitive constraints
:- op(700, xfx, [(.=.),(.<>.),(.<.),(.=<.),(.>.),(.>=.)]).
