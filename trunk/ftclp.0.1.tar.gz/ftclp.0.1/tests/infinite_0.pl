:- use_package(clpq).

% x=0; 
% while(*){ 
%  if(*) x= x+3; else x=x+1;
% }
% if (x<0) error();

% The model of this program is empty which means that the program is
% safe. 

entry_goal :- 
	clp_meta([ X .=. 0 ]), l(X).

:- tabled(l(num)).
l(X):- 
	clp_meta([ X1 .=. X+3]), 
	l(X1).
l(X):- 
	clp_meta([X1 .=. X+1]), 
	l(X1).
l(X):- 
	error_c(X).

:- tabled(error_c(num)).
error_c(X):- clp_meta([X .<. 0  ]).
