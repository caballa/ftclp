:- use_package(clpq).

/*
 mc(x) = if x>100 then x-10 else mc(mc(x+11))
 assert \forall x. mc(x) >= 91
*/

prove :- 
	mc(X,R),
	clp_meta([ R .<. 91]).

:- tabled(mc(num,num)).
mc(X,R):- 
	clp_meta([
                    X .>. 100, 
                    R .=. X - 10
                   ]). 

mc(X,R):- 
          clp_meta([
                    X .=<. 100,
	          X1 .=. X + 11
                   ]),
%	mc(X1,Y), mc(Y,R).
	mc_1(X1,Y), mc_2(Y ,R). 

:- tabled(mc_1(num,num)).
mc_1(X,Y):- mc(X,Y).

:- tabled(mc_2(num,num)).
mc_2(X,Y):- mc(X,Y).
	
